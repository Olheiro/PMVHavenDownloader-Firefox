// content.js
//
// Title and duration come from the page's JSON-LD VideoObject block.
// Creator/uploader do NOT reliably come from JSON-LD: pmvhaven's JSON-LD
// calls the *uploader* account "creator" even when the page itself shows
// a separate "Original Creator" credit for someone else (this happens
// when one account re-uploads/tags someone else's edit). So creator/
// uploader are read directly from the DOM instead:
//
//   - The account name always sits in an <h3> inside a link to
//     /users/<id>, next to a role badge that reads either "Creator" or
//     "Uploader".
//   - When the badge says "Uploader", the page also shows a separate
//     "Original Creator:" line with a link to /search?creator=<name> —
//     that link's text is the real creator.
//   - When there's no such link, the account itself is the creator (the
//     badge says "Creator"), so creator and uploader are the same name.
//
// The HLS master playlist URL used to come from that same JSON-LD block's
// `contentUrl` - a site update changed `contentUrl` to just be the page's
// own URL instead (for every VideoObject block on the page), so that's no
// longer where it lives. See getMasterPlaylistUrl() below for where it
// actually is now and why.

function getVideoJsonLd() {
  const scripts = document.querySelectorAll('script[type="application/ld+json"]');
  let best = null;
  for (const s of scripts) {
    let data;
    try {
      data = JSON.parse(s.textContent);
    } catch (e) {
      continue;
    }
    // Deliberately doesn't require anything about `contentUrl` here - an
    // earlier version of this check also required it to contain '.m3u8'
    // (back when that's where the master playlist URL lived), which had
    // the side effect of rejecting the whole block - losing title and
    // duration too, not just the playlist URL - the moment the site
    // stopped putting an .m3u8 URL there.
    if (data && data['@type'] === 'VideoObject') {
      best = data;
    }
  }
  return best;
}

function getUploaderAndCreator() {
  // The uploader/account name: first text node inside the h3 next to the
  // /users/ link (skip the role-badge <span> that follows it).
  let uploader = '';
  const h3 = document.querySelector('a[href^="/users/"] h3');
  if (h3) {
    for (const node of h3.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
        uploader = node.textContent.trim();
        break;
      }
    }
  }

  // If there's a separate "Original Creator" credit, that's the real
  // creator; otherwise the account itself is the creator.
  let creator = uploader;
  const creatorLink = document.querySelector('a[href*="/search?creator="]');
  if (creatorLink && creatorLink.textContent.trim()) {
    creator = creatorLink.textContent.trim();
  }

  return { uploader, creator };
}

// Parses an ISO 8601 duration (e.g. "PT5M33S") into whole seconds, or null
// if it's missing/unparseable. Used to turn a variant's playlist bandwidth
// into an estimated file size for display.
function parseIso8601Duration(iso) {
  if (typeof iso !== 'string') return null;
  const match = iso.match(/^PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?$/i);
  if (!match) return null;
  const hours = parseFloat(match[1] || '0');
  const minutes = parseFloat(match[2] || '0');
  const seconds = parseFloat(match[3] || '0');
  const total = hours * 3600 + minutes * 60 + seconds;
  return total > 0 ? total : null;
}

// The real master playlist URL now lives in the Nuxt SSR payload
// (`<script id="__NUXT_DATA__">`), as the video record's own
// `hlsMasterPlaylistUrl` field - not in the JSON-LD block anymore. That
// payload is Nuxt's "devalue" format: a flat array where some entries are
// plain values and others are integer *references* to other entries
// (structural sharing, so repeated values aren't duplicated) - fully
// resolving that reference graph just to reach one field isn't necessary
// here, since the actual URL string still appears verbatim as one of the
// array's own entries either way. JSON.parse-ing the payload (which
// correctly turns its \u002F-escaped slashes back into real '/', unlike
// scanning the raw text) then searching the result for a "*/master.m3u8"
// string finds it directly, without resolving any of the reference
// structure around it.
function getMasterPlaylistUrlFromNuxtData() {
  const script = document.getElementById('__NUXT_DATA__');
  if (!script || !script.textContent) return null;
  let text;
  try {
    text = JSON.stringify(JSON.parse(script.textContent));
  } catch (e) {
    return null;
  }
  const match = text.match(/https:\/\/[^"\\]*?\/master\.m3u8/);
  return match ? match[0] : null;
}

// The original, non-transcoded upload. The same Nuxt video record that holds
// `hlsMasterPlaylistUrl` also has `videoUrl` (the direct file the HLS
// variants were transcoded from) plus `width`, `height`, `fileSize` and
// `mimetype`. Values in that payload are integer references into the flat
// array, so each field is looked up through val(). Records are matched on
// the master playlist URL so a related-videos card on the page can never
// supply the wrong video's file.
function getOriginalVideoFromNuxtData(masterPlaylistUrl) {
  const script = document.getElementById('__NUXT_DATA__');
  if (!script || !script.textContent || !masterPlaylistUrl) return null;
  let data;
  try {
    data = JSON.parse(script.textContent);
  } catch (e) {
    return null;
  }
  if (!Array.isArray(data)) return null;
  const val = (ref) => (Number.isInteger(ref) && ref >= 0 && ref < data.length ? data[ref] : undefined);
  const num = (v) => (typeof v === 'number' && isFinite(v) && v > 0 ? v : null);
  for (const rec of data) {
    if (!rec || typeof rec !== 'object' || Array.isArray(rec) || !('videoUrl' in rec)) continue;
    if (val(rec.hlsMasterPlaylistUrl) !== masterPlaylistUrl) continue;
    const url = val(rec.videoUrl);
    if (typeof url !== 'string' || !/^https?:\/\//.test(url)) return null;
    const mimetype = val(rec.mimetype);
    return {
      url,
      width: num(val(rec.width)),
      height: num(val(rec.height)),
      fileSize: num(val(rec.fileSize)),
      mimetype: typeof mimetype === 'string' ? mimetype : '',
    };
  }
  return null;
}

// Prefers contentUrl when it's actually a playlist URL (in case a future
// site change moves it back, or some page variant still does this), and
// falls back to the Nuxt payload otherwise - which is the normal case now.
function getMasterPlaylistUrl(ld) {
  if (ld && typeof ld.contentUrl === 'string' && ld.contentUrl.includes('.m3u8')) {
    return ld.contentUrl;
  }
  return getMasterPlaylistUrlFromNuxtData();
}

function getVideoInfo() {
  const ld = getVideoJsonLd();

  const title =
    (ld && ld.name) ||
    document.querySelector('h1')?.textContent.trim() ||
    document.title.replace(/\s*-\s*PMVHaven\s*$/i, '').trim();

  const { uploader, creator } = getUploaderAndCreator();
  const masterPlaylistUrl = getMasterPlaylistUrl(ld);
  const durationSeconds = parseIso8601Duration(ld && ld.duration);
  const original = getOriginalVideoFromNuxtData(masterPlaylistUrl);

  return {
    title,
    creator,
    uploader,
    masterPlaylistUrl,
    durationSeconds,
    original, // { url, width, height, fileSize, mimetype } or null
    pageUrl: location.href,
  };
}

browser.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'GET_VIDEO_INFO') {
    sendResponse(getVideoInfo());
    return;
  }

  if (msg.type === 'SAVE_BLOB') {
    // Triggering the save from here (a real page) rather than from the
    // extension's background page is a deliberate choice, not incidental:
    // Firefox has long-standing, still-open bugs where blob: URLs created
    // in or saved from a background page fail outright or hang forever
    // (see Mozilla Bugzilla #1696174, #1271345, #1420419), and Mozilla's
    // own documented workaround is exactly this - create/save the blob
    // from a content script instead.
    try {
      const objectUrl = URL.createObjectURL(msg.blob);
      const a = document.createElement('a');
      a.href = objectUrl;
      a.download = msg.filename;
      a.style.display = 'none';
      document.body.appendChild(a);

      // Some mobile save dialogs (Android's system file picker in
      // particular) suggest a name from document.title rather than fully
      // respecting the <a download> attribute, which drops everything but
      // the bare page title (no creator/uploader/resolution). Set it to
      // the exact computed filename right before the click, then restore
      // it immediately after, so whichever source the dialog reads from
      // shows the same name either way.
      const originalTitle = document.title;
      document.title = msg.filename;
      a.click();
      document.title = originalTitle;

      a.remove();
      // Give the browser time to actually start reading from the blob
      // before revoking its URL.
      setTimeout(() => URL.revokeObjectURL(objectUrl), 30000);
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String(e && e.message ? e.message : e) });
    }
  }
});
